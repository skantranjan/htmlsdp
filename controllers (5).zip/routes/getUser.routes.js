const { getUserController } = require('../controllers/controller.getUser');
const { ssoTokenMiddleware } = require('../middleware/middleware.sso');

async function getUserRoutes(fastify, options) {
  // Protected route - requires SSO token
  fastify.post('/api/getuser', {
    preHandler: ssoTokenMiddleware
  }, getUserController);
}

module.exports = getUserRoutes;
