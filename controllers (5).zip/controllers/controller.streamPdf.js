const { BlobServiceClient } = require('@azure/storage-blob');
const { AzureCliCredential, DefaultAzureCredential } = require('@azure/identity');
const { URL } = require('url');

/**
 * PDF Streaming Controller
 * Streams PDF files from Azure Blob Storage with security validation
 */

// Azure Blob Storage configuration
const AZURE_STORAGE_CONNECTION_STRING = process.env.AZURE_STORAGE_CONNECTION_STRING;
const ALLOWED_BLOB_ACCOUNT = 'ukssdptldev001'; // Your Azure storage account name
const ALLOWED_CONTAINERS = ['sdpdevstoragecontainer', 'adobesign', 'pdfs']; // Allowed container names

// Azure authentication setup (same as existing project)
let credential;
if (process.env.NODE_ENV === 'production') {
  if (process.env.AZURE_USE_MANAGED_IDENTITY === 'true') {
    credential = new DefaultAzureCredential();
  } else {
    credential = new AzureCliCredential();
  }
} else {
  // Development environment
  credential = new AzureCliCredential();
}

const accountName = process.env.AZURE_STORAGE_ACCOUNT || 'ukssdptldev001';
const blobUrl = `https://${accountName}.blob.core.windows.net`;

/**
 * Validate Azure Blob Storage URL
 * @param {string} pdfUrl - The URL to validate
 * @returns {Object} Validation result with parsed components
 */
function validateBlobUrl(pdfUrl) {
  try {
    const url = new URL(pdfUrl);
    
    // Check if it's HTTPS
    if (url.protocol !== 'https:') {
      return {
        isValid: false,
        error: 'URL must use HTTPS protocol'
      };
    }
    
    // Extract account name from hostname
    const hostnameParts = url.hostname.split('.');
    if (hostnameParts.length < 3) {
      return {
        isValid: false,
        error: 'Invalid Azure Blob Storage URL format'
      };
    }
    
    const accountName = hostnameParts[0];
    
    // Validate account name
    if (accountName !== ALLOWED_BLOB_ACCOUNT) {
      return {
        isValid: false,
        error: `URL must be from allowed Azure storage account: ${ALLOWED_BLOB_ACCOUNT}`
      };
    }
    
    // Extract container and blob path
    const pathParts = url.pathname.split('/').filter(part => part.length > 0);
    if (pathParts.length < 2) {
      return {
        isValid: false,
        error: 'URL must contain container and blob path'
      };
    }
    
    const containerName = pathParts[0];
    const blobPath = pathParts.slice(1).join('/');
    
    // Validate container name
    if (!ALLOWED_CONTAINERS.includes(containerName)) {
      return {
        isValid: false,
        error: `Container '${containerName}' is not allowed. Allowed containers: ${ALLOWED_CONTAINERS.join(', ')}`
      };
    }
    
    return {
      isValid: true,
      accountName,
      containerName,
      blobPath,
      fullUrl: pdfUrl
    };
    
  } catch (error) {
    return {
      isValid: false,
      error: 'Invalid URL format'
    };
  }
}

/**
 * Get file extension from blob path
 * @param {string} blobPath - The blob path
 * @returns {string} File extension
 */
function getFileExtension(blobPath) {
  const lastDotIndex = blobPath.lastIndexOf('.');
  if (lastDotIndex === -1) return '';
  return blobPath.substring(lastDotIndex + 1).toLowerCase();
}

/**
 * Generate safe filename for Content-Disposition header
 * @param {string} blobPath - The blob path
 * @returns {string} Safe filename
 */
function generateSafeFilename(blobPath) {
  const filename = blobPath.split('/').pop();
  // Remove or replace unsafe characters
  return filename.replace(/[^a-zA-Z0-9._-]/g, '_');
}

/**
 * Stream PDF from Azure Blob Storage
 * @param {Object} request - Fastify request object
 * @param {Object} reply - Fastify reply object
 */
async function streamPdfController(request, reply) {
  try {
    console.log('📄 PDF Stream Request Started');
    
    // Extract pdfUrl from query parameters
    const { pdfUrl } = request.query;
    
    if (!pdfUrl) {
      console.log('❌ Missing pdfUrl parameter');
      return reply.code(400).send({
        success: false,
        message: 'pdfUrl query parameter is required',
        error: 'MISSING_PDF_URL'
      });
    }
    
    console.log(`🔍 Processing PDF URL: ${pdfUrl}`);
    
    // Validate the URL
    const urlValidation = validateBlobUrl(pdfUrl);
    if (!urlValidation.isValid) {
      console.log(`❌ URL validation failed: ${urlValidation.error}`);
      return reply.code(400).send({
        success: false,
        message: 'Invalid PDF URL',
        error: 'INVALID_PDF_URL',
        details: urlValidation.error
      });
    }
    
    const { containerName, blobPath } = urlValidation;
    console.log(`✅ URL validated - Container: ${containerName}, Blob: ${blobPath}`);
    
    // Initialize Azure Blob Service Client
    let blobServiceClient;
    if (AZURE_STORAGE_CONNECTION_STRING) {
      // Use connection string (preferred method)
      console.log('🔑 Using Azure Storage Connection String');
      blobServiceClient = BlobServiceClient.fromConnectionString(AZURE_STORAGE_CONNECTION_STRING);
    } else {
      // Use credential-based authentication (requires Azure CLI)
      console.log('🔑 Using Azure Credentials (requires Azure CLI)');
      try {
        blobServiceClient = new BlobServiceClient(blobUrl, credential);
      } catch (error) {
        console.error('❌ Azure authentication failed:', error.message);
        return reply.code(500).send({
          success: false,
          message: 'Azure authentication failed. Please configure AZURE_STORAGE_CONNECTION_STRING in your .env file',
          error: 'AZURE_AUTH_FAILED',
          details: 'Azure CLI not found or not authenticated. Use connection string instead.'
        });
      }
    }
    
    const containerClient = blobServiceClient.getContainerClient(containerName);
    const blobClient = containerClient.getBlobClient(blobPath);
    
    console.log(`🔗 Connecting to Azure Blob Storage...`);
    
    // Check if blob exists
    const blobExists = await blobClient.exists();
    if (!blobExists) {
      console.log(`❌ Blob not found: ${blobPath}`);
      return reply.code(404).send({
        success: false,
        message: 'PDF file not found',
        error: 'PDF_NOT_FOUND',
        container: containerName,
        blob: blobPath
      });
    }
    
    // Get blob properties
    const blobProperties = await blobClient.getProperties();
    const contentLength = blobProperties.contentLength;
    const lastModified = blobProperties.lastModified;
    
    console.log(`📊 Blob properties - Size: ${contentLength} bytes, Modified: ${lastModified}`);
    
    // Validate file type
    const fileExtension = getFileExtension(blobPath);
    const allowedExtensions = ['pdf', 'xlsx', 'xls', 'doc', 'docx'];
    if (!allowedExtensions.includes(fileExtension)) {
      console.log(`⚠️  Warning: File extension '${fileExtension}' is not in allowed list: ${allowedExtensions.join(', ')}`);
    }
    
    // Generate safe filename
    const safeFilename = generateSafeFilename(blobPath);
    
    // Set response headers based on file type
    let contentType = 'application/pdf';
    if (fileExtension === 'xlsx') {
      contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    } else if (fileExtension === 'xls') {
      contentType = 'application/vnd.ms-excel';
    } else if (fileExtension === 'docx') {
      contentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    } else if (fileExtension === 'doc') {
      contentType = 'application/msword';
    }
    
    reply.header('Content-Type', contentType);
    reply.header('Content-Disposition', `inline; filename="${safeFilename}"`);
    reply.header('Content-Length', contentLength);
    reply.header('Cache-Control', 'public, max-age=3600'); // Cache for 1 hour
    reply.header('Last-Modified', lastModified.toUTCString());
    reply.header('Accept-Ranges', 'bytes');
    
    console.log(`📤 Streaming PDF: ${safeFilename} (${contentLength} bytes)`);
    
    // Stream the blob content
    const downloadResponse = await blobClient.download();
    const readable = downloadResponse.readableStreamBody;
    
    // Handle stream errors
    readable.on('error', (error) => {
      console.error('❌ Stream error:', error);
      if (!reply.sent) {
        reply.code(500).send({
          success: false,
          message: 'Error streaming PDF content',
          error: 'STREAM_ERROR'
        });
      }
    });
    
    // Pipe the stream to response
    reply.send(readable);
    
    console.log('✅ PDF streaming completed successfully');
    
  } catch (error) {
    console.error('❌ PDF Stream Error:', error);
    
    // Handle specific Azure errors
    if (error.code === 'ContainerNotFound') {
      return reply.code(404).send({
        success: false,
        message: 'Container not found',
        error: 'CONTAINER_NOT_FOUND'
      });
    }
    
    if (error.code === 'BlobNotFound') {
      return reply.code(404).send({
        success: false,
        message: 'PDF file not found',
        error: 'BLOB_NOT_FOUND'
      });
    }
    
    if (error.code === 'AuthenticationFailed') {
      return reply.code(401).send({
        success: false,
        message: 'Azure authentication failed',
        error: 'AZURE_AUTH_FAILED'
      });
    }
    
    // Generic error response
    return reply.code(500).send({
      success: false,
      message: 'Internal server error while streaming PDF',
      error: 'INTERNAL_ERROR',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
}

/**
 * Health check for PDF streaming service
 * @param {Object} request - Fastify request object
 * @param {Object} reply - Fastify reply object
 */
async function pdfStreamHealthController(request, reply) {
  try {
    // Initialize Azure Blob Service Client
    let blobServiceClient;
    if (AZURE_STORAGE_CONNECTION_STRING) {
      // Use connection string (preferred method)
      blobServiceClient = BlobServiceClient.fromConnectionString(AZURE_STORAGE_CONNECTION_STRING);
    } else {
      // Use credential-based authentication (requires Azure CLI)
      try {
        blobServiceClient = new BlobServiceClient(blobUrl, credential);
      } catch (error) {
        return reply.code(503).send({
          success: false,
          message: 'PDF streaming service is unhealthy - Azure authentication failed',
          status: 'unhealthy',
          error: 'Azure CLI not found or not authenticated. Use connection string instead.'
        });
      }
    }
    
    // Test connection by listing containers
    const containers = blobServiceClient.listContainers();
    await containers.next(); // Just check if we can connect
    
    return reply.send({
      success: true,
      message: 'PDF streaming service is healthy',
      status: 'healthy',
      azure: {
        configured: true,
        account: ALLOWED_BLOB_ACCOUNT,
        allowedContainers: ALLOWED_CONTAINERS
      }
    });
    
  } catch (error) {
    console.error('❌ PDF Stream Health Check Error:', error);
    return reply.code(503).send({
      success: false,
      message: 'PDF streaming service is unhealthy',
      status: 'unhealthy',
      error: error.message
    });
  }
}

module.exports = {
  streamPdfController,
  pdfStreamHealthController
};