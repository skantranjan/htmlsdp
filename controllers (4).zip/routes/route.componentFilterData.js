const fastify = require('fastify');
const controller = require('../controllers/controller.componentFilterData');
const bearerTokenMiddleware = require('../middleware/middleware.bearer');

module.exports = async function (fastify, options) {
    
    // POST /api/components/filterdata-generatepdf - Enhanced for Excel sheet PDF generation
    fastify.post('/api/components/filterdata-generatepdf', {
        schema: {
            body: {
                type: 'object',
                properties: {
                    period: { type: 'string', nullable: true },
                    packaging_type: { type: 'string', nullable: true },
                    component_packaging_type: { type: 'string', nullable: true },
                    sku: { type: 'string', nullable: true },
                    component_fields: { type: 'string', nullable: true },
                    exclude_external: { type: 'boolean', nullable: true },
                    cm_code: { type: 'string' },
                    generate_pdf: { type: 'boolean', default: false },
                    audit_log: { type: 'boolean', default: true }
                },
                required: ['cm_code']
            },
            response: {
                200: {
                    type: 'object',
                    properties: {
                        success: { type: 'boolean' },
                        message: { type: 'string' },
                        data: { type: 'array' },
                        total_count: { type: 'number' },
                        query_info: { type: 'object' },
                        excel_pdf_generation: { type: 'object' },
                        pdf_generation: { type: 'object', nullable: true }
                    }
                }
            }
        },
        preHandler: [bearerTokenMiddleware]
    }, controller.getFilteredComponentData);

    // GET /api/components/filterdata-generatepdf (for testing without body)
    fastify.get('/api/components/filterdata-generatepdf', {
        schema: {
            querystring: {
                type: 'object',
                properties: {
                    period: { type: 'string', nullable: true },
                    packaging_type: { type: 'string', nullable: true },
                    component_packaging_type: { type: 'string', nullable: true },
                    sku: { type: 'string', nullable: true },
                    component_fields: { type: 'string', nullable: true },
                    exclude_external: { type: 'string', nullable: true },
                    cm_code: { type: 'string' },
                    generate_pdf: { type: 'string', nullable: true },
                    audit_log: { type: 'string', nullable: true }
                },
                required: ['cm_code']
            }
        },
        preHandler: [bearerTokenMiddleware]
    }, controller.getFilteredComponentData);

    // POST /api/components/generate-pdf-from-filtered-data - Enhanced for Excel sheet data
    fastify.post('/api/components/generate-pdf-from-filtered-data', {
        schema: {
            body: {
                type: 'object',
                properties: {
                    cm_code: { type: 'string' },
                    period: { type: 'string' },
                    email: { type: 'string', format: 'email' },
                    filters: {
                        type: 'object',
                        properties: {
                            packaging_type: { type: 'string', nullable: true },
                            component_packaging_type: { type: 'string', nullable: true },
                            sku: { type: 'string', nullable: true },
                            component_fields: { type: 'string', nullable: true },
                            exclude_external: { type: 'boolean', nullable: true }
                        }
                    }
                },
                required: ['cm_code', 'period', 'email']
            },
            response: {
                200: {
                    type: 'object',
                    properties: {
                        success: { type: 'boolean' },
                        message: { type: 'string' },
                        data: { type: 'array' },
                        total_count: { type: 'number' },
                        pdf_generation: { type: 'object' }
                    }
                }
            }
        },
        preHandler: [bearerTokenMiddleware]
    }, controller.generatePdfFromFilteredData);

    // POST /api/components/export-excel-sheet-data - New endpoint for Excel sheet export
    fastify.post('/api/components/export-excel-sheet-data', {
        schema: {
            body: {
                type: 'object',
                properties: {
                    cm_code: { type: 'string' },
                    period_id: { type: 'string' },
                    export_format: { type: 'string', default: 'excel' }
                },
                required: ['cm_code', 'period_id']
            },
            response: {
                200: {
                    type: 'object',
                    properties: {
                        success: { type: 'boolean' },
                        message: { type: 'string' },
                        data: { type: 'array' },
                        total_count: { type: 'number' },
                        export_info: { type: 'object' }
                    }
                }
            }
        },
        preHandler: [bearerTokenMiddleware]
    }, controller.exportExcelSheetData);
};
