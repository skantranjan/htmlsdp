const { 
  getAllRegionsController,
  getRegionByIdController,
  createRegionController,
  updateRegionController,
  deleteRegionController
} = require('../controllers/controller.regionMaster');
const bearerTokenMiddleware = require('../middleware/middleware.bearer');

async function regionMasterRoutes(fastify, options) {
  // Protected routes - requires Bearer token
  
  // Get all regions
  fastify.get('/api/regions', {
    preHandler: bearerTokenMiddleware
  }, getAllRegionsController);
  
  // Get region by ID
  fastify.get('/api/regions/:id', {
    preHandler: bearerTokenMiddleware
  }, getRegionByIdController);
  
  // Create new region
  fastify.post('/api/regions', {
    preHandler: bearerTokenMiddleware
  }, createRegionController);
  
  // Update region by ID
  fastify.put('/api/regions/:id', {
    preHandler: bearerTokenMiddleware
  }, updateRegionController);
  
  // Delete region by ID
  fastify.delete('/api/regions/:id', {
    preHandler: bearerTokenMiddleware
  }, deleteRegionController);
}

module.exports = regionMasterRoutes; 