import { useMsal } from '@azure/msal-react';
import { useTokenService } from '../utils/tokenService';
import { apiPost, apiGet, apiPut, apiPatch, apiDelete, apiPostWithParams, apiPostFormData, apiPutFormData } from '../utils/api';

export const useApiWithTokenRefresh = () => {
  const { instance } = useMsal();
  const { isTokenExpiring, getFreshToken } = useTokenService();

  // Enhanced API functions with automatic token refresh
  const apiPostWithRefresh = async (endpoint: string, data: any, contentType: string = 'application/json', accessToken?: string) => {
    try {
      // Check if token is expiring and refresh if needed
      if (accessToken && isTokenExpiring(accessToken)) {
        console.log('🔄 Token expiring soon, refreshing...');
        const accounts = instance.getAllAccounts();
        if (accounts.length > 0) {
          accessToken = await getFreshToken(accounts[0]);
        }
      }

      return await apiPost(endpoint, data, contentType, accessToken);
    } catch (error: any) {
      // If 401 error, try to refresh token and retry
      if (error.message && error.message.includes('401')) {
        console.log('🔄 API call failed with 401, refreshing token and retrying...');
        
        try {
          const accounts = instance.getAllAccounts();
          if (accounts.length > 0) {
            const freshToken = await getFreshToken(accounts[0]);
            return await apiPost(endpoint, data, contentType, freshToken);
          } else {
            throw new Error('No user account found. Please login again.');
          }
        } catch (refreshError) {
          console.error('❌ Token refresh failed:', refreshError);
          throw new Error('Token refresh failed. Please login again.');
        }
      }
      
      throw error;
    }
  };

  const apiGetWithRefresh = async (endpoint: string, params?: Record<string, any>, accessToken?: string) => {
    try {
      // Check if token is expiring and refresh if needed
      if (accessToken && isTokenExpiring(accessToken)) {
        console.log('🔄 Token expiring soon, refreshing...');
        const accounts = instance.getAllAccounts();
        if (accounts.length > 0) {
          accessToken = await getFreshToken(accounts[0]);
        }
      }

      return await apiGet(endpoint, params, accessToken);
    } catch (error: any) {
      // If 401 error, try to refresh token and retry
      if (error.message && error.message.includes('401')) {
        console.log('🔄 API call failed with 401, refreshing token and retrying...');
        
        try {
          const accounts = instance.getAllAccounts();
          if (accounts.length > 0) {
            const freshToken = await getFreshToken(accounts[0]);
            return await apiGet(endpoint, params, freshToken);
          } else {
            throw new Error('No user account found. Please login again.');
          }
        } catch (refreshError) {
          console.error('❌ Token refresh failed:', refreshError);
          throw new Error('Token refresh failed. Please login again.');
        }
      }
      
      throw error;
    }
  };

  const apiPostWithParamsWithRefresh = async (endpoint: string, params?: Record<string, any>, data?: any, accessToken?: string) => {
    try {
      // Check if token is expiring and refresh if needed
      if (accessToken && isTokenExpiring(accessToken)) {
        console.log('🔄 Token expiring soon, refreshing...');
        const accounts = instance.getAllAccounts();
        if (accounts.length > 0) {
          accessToken = await getFreshToken(accounts[0]);
        }
      }

      return await apiPostWithParams(endpoint, params, data, accessToken);
    } catch (error: any) {
      // If 401 error, try to refresh token and retry
      if (error.message && error.message.includes('401')) {
        console.log('🔄 API call failed with 401, refreshing token and retrying...');
        
        try {
          const accounts = instance.getAllAccounts();
          if (accounts.length > 0) {
            const freshToken = await getFreshToken(accounts[0]);
            return await apiPostWithParams(endpoint, params, data, freshToken);
          } else {
            throw new Error('No user account found. Please login again.');
          }
        } catch (refreshError) {
          console.error('❌ Token refresh failed:', refreshError);
          throw new Error('Token refresh failed. Please login again.');
        }
      }
      
      throw error;
    }
  };

  const apiPostFormDataWithRefresh = async (endpoint: string, formData: FormData, accessToken?: string) => {
    try {
      // If no access token provided, get it from MSAL
      if (!accessToken) {
        const accounts = instance.getAllAccounts();
        if (accounts.length > 0) {
          accessToken = await getFreshToken(accounts[0]);
        } else {
          throw new Error('No user account found. Please login again.');
        }
      }
      
      // Check if token is expiring and refresh if needed
      if (accessToken && isTokenExpiring(accessToken)) {
        console.log('🔄 Token expiring soon, refreshing...');
        const accounts = instance.getAllAccounts();
        if (accounts.length > 0) {
          accessToken = await getFreshToken(accounts[0]);
        }
      }

      return await apiPostFormData(endpoint, formData, accessToken);
    } catch (error: any) {
      // If 401 error, try to refresh token and retry
      if (error.message && error.message.includes('401')) {
        console.log('🔄 API call failed with 401, refreshing token and retrying...');
        
        try {
          const accounts = instance.getAllAccounts();
          if (accounts.length > 0) {
            const freshToken = await getFreshToken(accounts[0]);
            return await apiPostFormData(endpoint, formData, freshToken);
          } else {
            throw new Error('No user account found. Please login again.');
          }
        } catch (refreshError) {
          console.error('❌ Token refresh failed:', refreshError);
          throw new Error('Token refresh failed. Please login again.');
        }
      }
      
      throw error;
    }
  };

  return {
    apiPostWithRefresh,
    apiGetWithRefresh,
    apiPostWithParamsWithRefresh,
    apiPostFormDataWithRefresh
  };
};
