const db = require('../config/db.config');

/**
 * Get comprehensive audit log data with detailed component information
 * Uses the exact SQL query specified for comprehensive data retrieval
 */
const getAuditLog = async (request, reply) => {
    try {
        const { 
            cm_code, 
            period_id,
            sku_code,
            component_code,
            packaging_type,
            is_active,
            limit = 100,
            offset = 0
        } = request.body; // Changed from request.query to request.body for POST

        // Validate required cm_code parameter
        if (!cm_code) {
            // If no cm_code provided, we'll get all data without cm_code filter
            console.log('No cm_code provided - retrieving all data');
        }

        // Build dynamic WHERE clause
        let whereConditions = [];
        let queryParams = [];
        let paramIndex = 1;

        // Add cm_code filter only if provided
        if (cm_code) {
            whereConditions.push(`scm.cm_code = $${paramIndex}`);
            queryParams.push(cm_code);
            paramIndex++;
        }

        // Add optional filters
        if (period_id) {
            whereConditions.push(`scm.period_id = $${paramIndex}`);
            queryParams.push(period_id);
            paramIndex++;
        }

        if (sku_code) {
            whereConditions.push(`scm.sku_code = $${paramIndex}`);
            queryParams.push(sku_code);
            paramIndex++;
        }

        if (component_code) {
            whereConditions.push(`scm.component_code = $${paramIndex}`);
            queryParams.push(component_code);
            paramIndex++;
        }

        if (packaging_type) {
            whereConditions.push(`scm.component_packaging_type_id = $${paramIndex}`);
            queryParams.push(packaging_type);
            paramIndex++;
        }

        if (is_active !== undefined && is_active !== null) {
            whereConditions.push(`scm.is_active = $${paramIndex}`);
            queryParams.push(is_active);
            paramIndex++;
        }

        // Build the complete comprehensive query as specified
        const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';
        
        const comprehensiveQuery = `
            SELECT DISTINCT ON (scm.cm_code, scm.sku_code, scm.component_code, scm.version)
                scm.cm_code,
                scm.sku_code,
                scm.component_code,
                scm.version,
                scm.period_id,
                p.period AS period_name,
                scm.component_valid_from,
                scm.component_valid_to,
                scm.component_packaging_type_id AS packaging_type_name,
                cd.component_packaging_material AS packaging_material_name,
                scm.created_by AS mapping_created_by,
                u.username AS mapping_created_by_name,
                scm.created_at AS mapping_created_at,
                scm.updated_at AS mapping_updated_at,
                scm.is_active AS mapping_is_active,
                scm.componentvaliditydatefrom,
                scm.componentvaliditydateto,
                sd.*,
                cd.id AS component_id,
                cd.formulation_reference,
                cd.material_type_id,
                mt.item_name AS material_type_name,
                cd.component_description,
                cd.component_valid_from AS component_master_valid_from,
                cd.component_valid_to AS component_master_valid_to,
                cd.component_material_group,
                cd.component_quantity,
                cd.component_uom_id,
                uom.item_name AS component_uom_name,
                cd.component_base_quantity,
                cd.component_base_uom_id,
                base_uom.item_name AS component_base_uom_name,
                cd.percent_w_w,
                cd.evidence,
                cd.component_packaging_material,
                cd.helper_column,
                cd.component_unit_weight,
                cd.weight_unit_measure_id,
                cd.percent_mechanical_pcr_content,
                cd.percent_mechanical_pir_content,
                cd.percent_chemical_recycled_content,
                cd.percent_bio_sourced,
                cd.material_structure_multimaterials,
                cd.component_packaging_color_opacity,
                cd.component_packaging_level_id,
                cd.component_dimensions,
                cd.packaging_specification_evidence,
                cd.evidence_of_recycled_or_bio_source,
                cd.last_update_date,
                cd.category_entry_id,
                cd.data_verification_entry_id,
                cd.user_id,
                cd.signed_off_by,
                su.username AS signed_off_by_name,
                cd.signed_off_date,
                cd.mandatory_fields_completion_status,
                cd.evidence_provided,
                cd.document_status,
                cd.is_active AS component_is_active,
                cd.created_by AS component_created_by,
                cd.created_date AS component_created_date,
                cd.year,
                cd.component_unit_weight_id,
                cd.periods,
                cd.version AS component_version,
                cd.componentvaliditydatefrom AS component_master_validity_from,
                cd.componentvaliditydateto AS component_master_validity_to
            FROM 
                public.sdp_sku_component_mapping_details scm
            LEFT JOIN public.sdp_skudetails sd 
                ON scm.sku_code = sd.sku_code AND scm.cm_code = sd.cm_code
            LEFT JOIN public.sdp_component_details cd 
                ON scm.component_code = cd.component_code 
                   AND scm.sku_code = cd.sku_code 
                   AND scm.cm_code = sd.cm_code
            LEFT JOIN public.sdp_users u ON scm.created_by = u.username
            LEFT JOIN public.sdp_users su ON cd.signed_off_by = su.id
            LEFT JOIN public.sdp_period p ON scm.period_id = p.id
            LEFT JOIN public.sdp_material_type mt ON cd.material_type_id = mt.item_name
            LEFT JOIN public.sdp_component_uom uom ON cd.component_uom_id::text = uom.id::text
            LEFT JOIN public.sdp_component_base_uom base_uom ON cd.component_base_uom_id::text = base_uom.id::text
            ${whereClause}
            ORDER BY 
                scm.cm_code, scm.sku_code, scm.component_code, scm.version
            LIMIT $${paramIndex++} OFFSET $${paramIndex++}
        `;

        // Add limit and offset to query parameters
        queryParams.push(parseInt(limit), parseInt(offset));

        console.log('Audit Log Query:', comprehensiveQuery);
        console.log('Query Parameters:', queryParams);
        console.log('CM Code Filter:', cm_code);
        console.log('Where Conditions:', whereConditions);
        console.log('Where Clause:', whereClause);

        // Execute the query
        const result = await db.query(comprehensiveQuery, queryParams);

        // Get total count for pagination (without limit/offset)
        const countQuery = `
            SELECT COUNT(DISTINCT (scm.cm_code, scm.sku_code, scm.component_code, scm.version)) as total
            FROM 
                public.sdp_sku_component_mapping_details scm
            LEFT JOIN public.sdp_skudetails sd 
                ON scm.sku_code = sd.sku_code AND scm.cm_code = sd.cm_code
            LEFT JOIN public.sdp_component_details cd 
                ON scm.component_code = cd.component_code 
                   AND scm.sku_code = cd.sku_code 
                   AND scm.cm_code = sd.cm_code
            ${whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : ''}
        `;

        const countResult = await db.query(countQuery, queryParams.slice(0, -2));
        const totalCount = parseInt(countResult.rows[0].total);

        // Prepare response data
        const responseData = {
            success: true,
            message: 'Audit log data retrieved successfully',
            data: {
                records: result.rows,
                pagination: {
                    total: totalCount,
                    limit: parseInt(limit),
                    offset: parseInt(offset),
                    has_more: (parseInt(offset) + parseInt(limit)) < totalCount,
                    current_page: Math.floor(parseInt(offset) / parseInt(limit)) + 1,
                    total_pages: Math.ceil(totalCount / parseInt(limit))
                },
                filters_applied: {
                    cm_code,
                    period_id,
                    sku_code,
                    component_code,
                    packaging_type,
                    is_active
                },
                query_summary: {
                    cm_code,
                    total_records: totalCount,
                    returned_records: result.rows.length,
                    query_executed_at: new Date().toISOString()
                }
            }
        };

        return reply.send(responseData);

    } catch (error) {
        console.error('Error in getAuditLog:', error);
        return reply.code(500).send({
            success: false,
            message: 'Internal server error while retrieving audit log data',
            error: error.message
        });
    }
};

module.exports = {
    getAuditLog
};
