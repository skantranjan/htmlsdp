const { addComponentController } = require('../controllers/controller.addComponent');

async function addComponentRoutes(fastify, options) {
  // Public route - no authentication required
  fastify.post('/api/add-component', addComponentController);
}

module.exports = addComponentRoutes;
