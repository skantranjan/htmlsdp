import React from 'react';
import { useMsal } from '@azure/msal-react';
import { loginRequest } from '../config/msalConfig';

interface SSOButtonProps {
  onLoginSuccess?: (email: string) => void;
  onLoginError?: (error: string) => void;
  className?: string;
  children?: React.ReactNode;
}

const SSOButton: React.FC<SSOButtonProps> = ({ 
  onLoginSuccess, 
  onLoginError, 
  className = '',
  children = 'Sign in with Microsoft'
}) => {
  const { instance } = useMsal();

  const handleSSOLogin = async () => {
    try {
      // Attempt to login with popup
      const response = await instance.loginPopup(loginRequest);
      
      if (response.account) {
        // Get user info from Microsoft Graph
        const graphResponse = await instance.acquireTokenSilent({
          ...loginRequest,
          account: response.account
        });

        if (graphResponse.accessToken) {
          // Call Microsoft Graph to get user details
          const userInfo = await fetch('https://graph.microsoft.com/v1.0/me', {
            headers: {
              'Authorization': `Bearer ${graphResponse.accessToken}`,
              'Content-Type': 'application/json'
            }
          });

          if (userInfo.ok) {
            const userData = await userInfo.json();
            const email = userData.mail || userData.userPrincipalName;
            
            if (email) {
              console.log('SSO Login successful:', { email, userData });
              onLoginSuccess?.(email);
            } else {
              throw new Error('Email not found in user profile');
            }
          } else {
            throw new Error('Failed to fetch user info from Microsoft Graph');
          }
        } else {
          throw new Error('Failed to acquire access token');
        }
      } else {
        throw new Error('No account information received');
      }
    } catch (error: any) {
      console.error('SSO Login error:', error);
      const errorMessage = error.message || 'SSO authentication failed';
      onLoginError?.(errorMessage);
    }
  };

  return (
    <button
      onClick={handleSSOLogin}
      className={`sso-button ${className}`}
      type="button"
    >
      <svg 
        width="20" 
        height="20" 
        viewBox="0 0 20 20" 
        fill="currentColor"
        style={{ marginRight: '8px' }}
      >
        <path d="M10 0C4.477 0 0 4.477 0 10s4.477 10 10 10 10-4.477 10-10S15.523 0 10 0zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z"/>
        <path d="M13.5 10c0 1.933-1.567 3.5-3.5 3.5S6.5 11.933 6.5 10 8.067 6.5 10 6.5s3.5 1.567 3.5 3.5z"/>
      </svg>
      {children}
    </button>
  );
};

export default SSOButton;
